package com.tenda.sp3quick;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;

abstract class BaseWidget extends AppWidgetProvider {
    abstract String device();
    abstract String toggleAction();

    @Override public void onUpdate(Context ctx, AppWidgetManager manager, int[] ids) {
        WidgetHelper.updateAll(ctx);
    }

    @Override public void onReceive(Context ctx, Intent intent) {
        super.onReceive(ctx, intent);
        if (toggleAction().equals(intent.getAction())) {
            // Keep the receiver alive while the LAN request completes.
            PendingResult pending = goAsync();
            Controller.toggle(ctx.getApplicationContext(), device(), (success, message) -> pending.finish());
        }
    }
}
