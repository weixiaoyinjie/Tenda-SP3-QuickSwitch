package com.tenda.sp3quick;
public final class FanWidget extends BaseWidget {
    @Override String device() { return Devices.FAN; }
    @Override String toggleAction() { return WidgetHelper.TOGGLE_FAN; }
}
