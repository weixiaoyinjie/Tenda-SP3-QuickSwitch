package com.tenda.sp3quick;
public final class LightWidget extends BaseWidget {
    @Override String device() { return Devices.LIGHT; }
    @Override String toggleAction() { return WidgetHelper.TOGGLE_LIGHT; }
}
