package com.tenda.sp3quick;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Toast;

/** Launched by a pinned home-screen shortcut; does not open the main app UI. */
public final class ShortcutToggleActivity extends Activity {
    static final String KEY_DEVICE = "device";

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        String device = getIntent().getStringExtra(KEY_DEVICE);
        if (!Devices.LIGHT.equals(device) && !Devices.FAN.equals(device)) {
            finish();
            return;
        }
        Toast.makeText(this, "正在切换" + Devices.name(device), Toast.LENGTH_SHORT).show();
        Controller.toggle(this, device, (success, message) -> runOnUiThread(() -> {
            Toast.makeText(this, success ? message : Devices.name(device) + "：" + message, Toast.LENGTH_LONG).show();
            finish();
        }));
    }
}
