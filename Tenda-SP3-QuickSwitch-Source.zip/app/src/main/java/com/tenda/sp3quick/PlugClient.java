package com.tenda.sp3quick;

import org.json.JSONException;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/** Tenda Beli SP3: local TCP/5000 HTTP protocol (no cloud credentials). */
final class PlugClient {
    private final String ip;
    PlugClient(String ip) { this.ip = ip; }

    JSONObject detail() throws Exception { return request("GET", "getDetail", null, 1100, 1200).getJSONObject("data"); }

    String mac() throws Exception { return detail().optString("mac", "").toUpperCase(); }

    void verify(String expectedMac) throws Exception {
        String actual = mac();
        if (!actual.replace("-", ":").equalsIgnoreCase(expectedMac)) {
            throw new IOException("MAC 不匹配：目标 " + expectedMac + "，实际 " + actual);
        }
    }

    int getState() throws Exception {
        JSONObject result = request("POST", "getSta", new byte[0], 1400, 1400);
        JSONObject data = result.optJSONObject("data");
        if (data == null || !data.has("status")) throw new IOException("设备没有返回开关状态");
        int s = data.getInt("status");
        if (s != 0 && s != 1) throw new IOException("异常状态码：" + s);
        return s;
    }

    void setState(int s) throws Exception {
        JSONObject input = new JSONObject();
        input.put("status", s);
        JSONObject result = request("POST", "setSta", input.toString().getBytes(StandardCharsets.UTF_8), 1400, 1400);
        if (result.has("status") && result.getInt("status") != s) throw new IOException("开关反馈状态不一致");
    }

    static String getMacFast(String ip) throws Exception {
        JSONObject data = new PlugClient(ip).request("GET", "getDetail", null, 350, 600).optJSONObject("data");
        return data == null ? "" : data.optString("mac", "");
    }

    private JSONObject request(String method, String path, byte[] body, int connectMs, int readMs) throws Exception {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL("http://" + ip + ":5000/" + path).openConnection();
            c.setRequestMethod(method);
            c.setConnectTimeout(connectMs);
            c.setReadTimeout(readMs);
            c.setUseCaches(false);
            c.setRequestProperty("Accept", "application/json");
            c.setRequestProperty("Connection", "close");
            if (body != null) {
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                c.setFixedLengthStreamingMode(body.length);
                try (OutputStream out = c.getOutputStream()) { out.write(body); }
            }
            int code = c.getResponseCode();
            if (code != 200) throw new IOException("HTTP " + code + " /" + path);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try (InputStream in = c.getInputStream()) {
                byte[] buf = new byte[1024];
                int n;
                while ((n = in.read(buf)) != -1) {
                    out.write(buf, 0, n);
                    if (out.size() > 8192) throw new IOException("响应过大");
                }
            }
            JSONObject json = new JSONObject(new String(out.toByteArray(), StandardCharsets.UTF_8));
            if (json.optInt("resp_code", -999) != 0) {
                throw new IOException("设备拒绝命令：" + json.optInt("resp_code", -999));
            }
            return json;
        } catch (JSONException e) {
            throw new IOException("设备返回的数据格式不正确", e);
        } finally {
            if (c != null) c.disconnect();
        }
    }
}
