package com.tenda.sp3quick;

import android.content.Context;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/** Only scans the phone's current Wi-Fi /24 for SP3 MAC IDs; read-only GET requests. */
final class Discovery {
    interface Done { void complete(String message); }
    private static final class Found {
        final String ip, mac;
        Found(String ip, String mac) { this.ip = ip; this.mac = mac; }
    }

    static void search(Context context, Done done) {
        Context app = context.getApplicationContext();
        new Thread(() -> {
            String result;
            try {
                String prefix = wifiPrefix();
                ExecutorService pool = Executors.newFixedThreadPool(24);
                CompletionService<Found> queue = new ExecutorCompletionService<>(pool);
                try {
                    for (int i = 1; i < 255; i++) {
                        final String ip = prefix + i;
                        queue.submit(() -> {
                            try {
                                String mac = PlugClient.getMacFast(ip);
                                if (mac == null || mac.isEmpty()) return null;
                                return new Found(ip, mac);
                            } catch (Exception ignored) { return null; }
                        });
                    }
                    Map<String, String> matched = new HashMap<>();
                    for (int i = 1; i < 255; i++) {
                        Future<Found> future = queue.poll(16, TimeUnit.SECONDS);
                        if (future == null) break;
                        Found found = future.get();
                        if (found == null) continue;
                        if (found.mac.equalsIgnoreCase(Devices.mac(Devices.LIGHT))) {
                            matched.put(Devices.LIGHT, found.ip);
                        }
                        if (found.mac.equalsIgnoreCase(Devices.mac(Devices.FAN))) {
                            matched.put(Devices.FAN, found.ip);
                        }
                        if (matched.size() == 2) break;
                    }
                    for (Map.Entry<String, String> entry : matched.entrySet()) {
                        Devices.setIp(app, entry.getKey(), entry.getValue());
                    }
                    result = matched.isEmpty() ? "当前 Wi-Fi 未发现目标插座；请检查网络或手动设置 IP" :
                            "找到 " + matched.size() + " 台：" +
                            (matched.containsKey(Devices.LIGHT) ? " 电灯 " + matched.get(Devices.LIGHT) : "") +
                            (matched.containsKey(Devices.FAN) ? " 电风扇 " + matched.get(Devices.FAN) : "");
                } finally {
                    pool.shutdownNow();
                }
            } catch (Exception e) {
                result = "自动查找失败：" + (e.getMessage() == null ? "请连接家庭 Wi-Fi" : e.getMessage());
            }
            done.complete(result);
        }, "SP3-discover").start();
    }

    private static String wifiPrefix() throws Exception {
        NetworkInterface wifi = NetworkInterface.getByName("wlan0");
        if (wifi == null || !wifi.isUp()) throw new IllegalStateException("未检测到 Wi-Fi 接口；请连接家庭 Wi-Fi");
        Enumeration<InetAddress> addrs = wifi.getInetAddresses();
        while (addrs.hasMoreElements()) {
            InetAddress a = addrs.nextElement();
            if (a instanceof Inet4Address && a.isSiteLocalAddress()) {
                String s = a.getHostAddress();
                return s.substring(0, s.lastIndexOf('.') + 1);
            }
        }
        throw new IllegalStateException("未获取到 Wi-Fi 局域网 IPv4 地址");
    }
}
