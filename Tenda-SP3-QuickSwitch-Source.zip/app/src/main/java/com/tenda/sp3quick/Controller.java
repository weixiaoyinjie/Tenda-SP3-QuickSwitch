package com.tenda.sp3quick;

import android.content.Context;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class Controller {
    interface Done { void finished(boolean success, String message); }
    private static final ExecutorService WORKER = Executors.newSingleThreadExecutor();

    static void refresh(Context ctx, String device, Done callback) {
        Context app = ctx.getApplicationContext();
        WORKER.execute(() -> {
            try {
                PlugClient plug = new PlugClient(Devices.ip(app, device));
                if (Devices.verifyMac(app)) plug.verify(Devices.mac(device));
                int state = plug.getState();
                Devices.setError(app, device, "");
                Devices.setStatus(app, device, state);
                if (callback != null) callback.finished(true, Devices.name(device) + "状态已更新");
            } catch (Exception e) {
                fail(app, device, e);
                if (callback != null) callback.finished(false, e.getMessage());
            }
        });
    }

    static void toggle(Context ctx, String device, Done callback) {
        Context app = ctx.getApplicationContext();
        // Query real state immediately before changing it, avoiding a stale widget state.
        Devices.setStatus(app, device, Devices.PENDING);
        WORKER.execute(() -> {
            try {
                PlugClient plug = new PlugClient(Devices.ip(app, device));
                if (Devices.verifyMac(app)) plug.verify(Devices.mac(device));
                int actual = plug.getState();
                int desired = actual == 1 ? 0 : 1;
                plug.setState(desired);
                int confirmed = plug.getState();
                if (confirmed != desired) throw new IllegalStateException("设备未确认新状态，请稍后刷新");
                Devices.setError(app, device, "");
                Devices.setStatus(app, device, confirmed);
                if (callback != null) callback.finished(true, Devices.name(device) + (confirmed == 1 ? "已开启" : "已关闭"));
            } catch (Exception e) {
                fail(app, device, e);
                if (callback != null) callback.finished(false, e.getMessage());
            }
        });
    }

    private static void fail(Context ctx, String device, Exception e) {
        String detail = e.getMessage();
        if (detail == null || detail.trim().isEmpty()) detail = "网络连接失败";
        Devices.setError(ctx, device, detail);
        Devices.setStatus(ctx, device, Devices.UNKNOWN);
    }
}
