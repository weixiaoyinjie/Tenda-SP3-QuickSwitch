package com.tenda.sp3quick;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

final class WidgetHelper {
    static final String TOGGLE_LIGHT = "com.tenda.sp3quick.TOGGLE_LIGHT";
    static final String TOGGLE_FAN = "com.tenda.sp3quick.TOGGLE_FAN";

    static void updateAll(Context ctx) {
        update(ctx, Devices.LIGHT, LightWidget.class);
        update(ctx, Devices.FAN, FanWidget.class);
    }

    static void update(Context ctx, String device, Class<?> provider) {
        AppWidgetManager manager = AppWidgetManager.getInstance(ctx);
        int[] ids = manager.getAppWidgetIds(new ComponentName(ctx, provider));
        int status = Devices.status(ctx, device);
        for (int id : ids) {
            int layout = status == 1 ? R.layout.widget_item_on :
                    status == Devices.PENDING ? R.layout.widget_item_pending : R.layout.widget_item;
            RemoteViews view = new RemoteViews(ctx.getPackageName(), layout);
            view.setTextViewText(R.id.widget_icon, Devices.icon(device));
            view.setTextViewText(R.id.widget_name, Devices.name(device));
            view.setTextViewText(R.id.widget_state, status == 1 ? "已开启" : status == 0 ? "已关闭" : status == Devices.PENDING ? "处理中…" : "未连接");
            Class<?> cls = Devices.LIGHT.equals(device) ? LightWidget.class : FanWidget.class;
            String action = Devices.LIGHT.equals(device) ? TOGGLE_LIGHT : TOGGLE_FAN;
            Intent i = new Intent(ctx, cls).setAction(action);
            PendingIntent pending = PendingIntent.getBroadcast(ctx, Devices.LIGHT.equals(device) ? 12 : 13,
                    i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            view.setOnClickPendingIntent(R.id.widget_container, pending);
            manager.updateAppWidget(id, view);
        }
    }
}
