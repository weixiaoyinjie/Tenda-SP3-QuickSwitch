package com.tenda.sp3quick;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.drawable.Icon;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public final class MainActivity extends Activity {
    private final int BG = Color.rgb(8, 13, 21);
    private final int CARD = Color.rgb(24, 34, 48);
    private final int MUTED = Color.rgb(153, 172, 190);
    private Button lightButton, fanButton;
    private TextView lightState, fanState, lightIp, fanIp;
    private boolean scanning = false;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        render();
    }

    @Override protected void onResume() {
        super.onResume();
        render();
        refresh(false);
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setPadding(dp(22), dp(30), dp(22), dp(30));
        scroll.addView(column);

        TextView title = label("快捷开关", 30, Color.WHITE, true);
        column.addView(title);
        TextView subtitle = label("Tenda SP3 · 本地 Wi-Fi 控制", 14, MUTED, false);
        LinearLayout.LayoutParams sub = new LinearLayout.LayoutParams(-1, -2);
        sub.topMargin = dp(5);
        sub.bottomMargin = dp(26);
        column.addView(subtitle, sub);

        LinearLayout l = createCard(column, Devices.LIGHT, "💡", "电灯");
        lightState = (TextView) l.findViewWithTag("state");
        lightIp = (TextView) l.findViewWithTag("ip");
        lightButton = (Button) l.findViewWithTag("action");
        lightButton.setOnClickListener(v -> toggle(Devices.LIGHT));

        LinearLayout f = createCard(column, Devices.FAN, "🌀", "电风扇");
        fanState = (TextView) f.findViewWithTag("state");
        fanIp = (TextView) f.findViewWithTag("ip");
        fanButton = (Button) f.findViewWithTag("action");
        fanButton.setOnClickListener(v -> toggle(Devices.FAN));

        TextView shortcutHeader = label("添加桌面快捷方式", 16, Color.WHITE, true);
        LinearLayout.LayoutParams sh = new LinearLayout.LayoutParams(-1, -2);
        sh.topMargin = dp(8);
        sh.bottomMargin = dp(12);
        column.addView(shortcutHeader, sh);
        Button pinLight = utility("＋ 电灯 · 桌面快捷方式");
        column.addView(pinLight);
        pinLight.setOnClickListener(v -> pinShortcut(Devices.LIGHT));
        Button pinFan = utility("＋ 电风扇 · 桌面快捷方式");
        column.addView(pinFan);
        pinFan.setOnClickListener(v -> pinShortcut(Devices.FAN));

        Button refresh = utility("刷新设备状态");
        column.addView(refresh);
        refresh.setOnClickListener(v -> refresh(true));

        Button find = utility("自动查找插座 IP");
        column.addView(find);
        find.setOnClickListener(v -> {
            if (scanning) return;
            scanning = true;
            find.setEnabled(false);
            find.setText("正在查找…");
            Discovery.search(this, result -> runOnUiThread(() -> {
                scanning = false;
                find.setEnabled(true);
                find.setText("自动查找插座 IP");
                toast(result);
                render();
                refresh(false);
            }));
        });

        Button settings = utility("设置 IP / MAC 校验");
        column.addView(settings);
        settings.setOnClickListener(v -> openSettings());

        TextView footer = label("可使用上方按钮添加两个独立桌面快捷图标。也可长按桌面空白处 → 小组件 → 电灯·风扇快捷开关，分别添加电灯和电风扇。\n\n只在与插座互通的家庭局域网使用；不需要 Tenda 账号。", 12, MUTED, false);
        LinearLayout.LayoutParams footerParams = new LinearLayout.LayoutParams(-1, -2);
        footerParams.topMargin = dp(19);
        column.addView(footer, footerParams);
        setContentView(scroll);
    }

    private LinearLayout createCard(LinearLayout parent, String device, String emoji, String name) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(19), dp(18), dp(19), dp(17));
        card.setBackground(round(CARD, 20));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.bottomMargin = dp(15);
        parent.addView(card, cp);
        TextView nameView = label(emoji + "  " + name, 23, Color.WHITE, true);
        card.addView(nameView);
        TextView status = label("正在检查…", 14, MUTED, false);
        status.setTag("state");
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = dp(12);
        card.addView(status, sp);
        TextView ip = label("", 12, MUTED, false);
        ip.setTag("ip");
        LinearLayout.LayoutParams ipp = new LinearLayout.LayoutParams(-1, -2);
        ipp.topMargin = dp(4);
        card.addView(ip, ipp);
        Button action = new Button(this);
        action.setTag("action");
        action.setAllCaps(false);
        action.setTextSize(17);
        action.setTextColor(Color.WHITE);
        action.setMinimumHeight(dp(54));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, dp(58));
        ap.topMargin = dp(19);
        card.addView(action, ap);
        return card;
    }

    private void toggle(String device) {
        Controller.toggle(this, device, (ok, msg) -> runOnUiThread(() -> {
            if (!isFinishing()) {
                render();
                if (!ok) toast(Devices.name(device) + "：" + msg);
            }
        }));
        render();
    }

    private void refresh(boolean toastOnFailure) {
        for (String device : new String[] { Devices.LIGHT, Devices.FAN }) {
            Controller.refresh(this, device, (success, message) -> runOnUiThread(() -> {
                if (!isFinishing()) {
                    render();
                    if (!success && toastOnFailure) toast(Devices.name(device) + "：" + message);
                }
            }));
        }
    }

    private void render() {
        updateCard(Devices.LIGHT, lightButton, lightState, lightIp);
        updateCard(Devices.FAN, fanButton, fanState, fanIp);
    }

    private void updateCard(String device, Button button, TextView status, TextView ipLabel) {
        if (button == null) return;
        int state = Devices.status(this, device);
        String error = Devices.error(this, device);
        String description;
        int color;
        if (state == 1) {
            description = "● 已开启";
            color = Color.rgb(29, 121, 98);
            button.setText("关闭" + Devices.name(device));
        } else if (state == 0) {
            description = "○ 已关闭";
            color = Color.rgb(70, 88, 109);
            button.setText("开启" + Devices.name(device));
        } else if (state == Devices.PENDING) {
            description = "正在读取并切换…";
            color = Color.rgb(132, 91, 36);
            button.setText("处理中…");
        } else {
            description = error.isEmpty() ? "尚未检测到状态" : "连接失败：" + error;
            color = Color.rgb(92, 79, 67);
            button.setText("检测并切换");
        }
        status.setText(description);
        status.setTextColor(state == 1 ? Color.rgb(117, 227, 194) : MUTED);
        ipLabel.setText("IP  " + Devices.ip(this, device) + "   ·   TCP 5000");
        button.setBackgroundTintList(ColorStateList.valueOf(color));
        button.setEnabled(state != Devices.PENDING);
    }

    private void pinShortcut(String device) {
        ShortcutManager shortcuts = getSystemService(ShortcutManager.class);
        if (shortcuts == null || !shortcuts.isRequestPinShortcutSupported()) {
            toast("桌面启动器不支持自动添加捷径，请使用小组件代替");
            return;
        }
        Intent intent = new Intent(this, ShortcutToggleActivity.class)
                .setAction(Intent.ACTION_VIEW)
                .putExtra(ShortcutToggleActivity.KEY_DEVICE, device);
        int resId = Devices.LIGHT.equals(device) ? R.drawable.shortcut_light : R.drawable.shortcut_fan;
        ShortcutInfo info = new ShortcutInfo.Builder(this, "sp3_" + device)
                .setShortLabel(Devices.name(device) + "开关")
                .setLongLabel("点击切换" + Devices.name(device))
                .setIcon(Icon.createWithResource(this, resId))
                .setIntent(intent)
                .build();
        boolean initiated = shortcuts.requestPinShortcut(info, null);
        toast(initiated ? "请按系统提示把" + Devices.name(device) + "添加到桌面" : "无法创建快捷方式");
    }

    private void openSettings() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(20), dp(12), dp(20), dp(4));
        TextView lightLabel = label("电灯 IP", 14, Color.DKGRAY, false);
        EditText lightEdit = ipField(Devices.ip(this, Devices.LIGHT));
        TextView fanLabel = label("电风扇 IP", 14, Color.DKGRAY, false);
        EditText fanEdit = ipField(Devices.ip(this, Devices.FAN));
        CheckBox verify = new CheckBox(this);
        verify.setText("切换前校验设备 MAC（推荐）");
        verify.setChecked(Devices.verifyMac(this));
        layout.addView(lightLabel);
        layout.addView(lightEdit);
        layout.addView(fanLabel);
        layout.addView(fanEdit);
        layout.addView(verify);
        AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("局域网设备设置")
                .setMessage("IP 变化时可手动修改，或使用自动查找。MAC 固定为截图中的两台插座。")
                .setView(layout)
                .setNegativeButton("取消", null)
                .setPositiveButton("保存", null)
                .create();
        dlg.setOnShowListener(ignore -> dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String ip1 = lightEdit.getText().toString().trim();
            String ip2 = fanEdit.getText().toString().trim();
            if (!validIp(ip1) || !validIp(ip2)) {
                toast("请输入有效的 IPv4 地址，例如 192.168.0.30");
                return;
            }
            if (ip1.equals(ip2)) {
                toast("两台插座不能使用相同 IP");
                return;
            }
            Devices.setIp(this, Devices.LIGHT, ip1);
            Devices.setIp(this, Devices.FAN, ip2);
            Devices.setVerifyMac(this, verify.isChecked());
            Devices.setStatus(this, Devices.LIGHT, Devices.UNKNOWN);
            Devices.setStatus(this, Devices.FAN, Devices.UNKNOWN);
            Devices.setError(this, Devices.LIGHT, "");
            Devices.setError(this, Devices.FAN, "");
            dlg.dismiss();
            render();
            refresh(false);
        }));
        dlg.show();
    }

    private EditText ipField(String initial) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setText(initial);
        e.setSelectAllOnFocus(true);
        e.setInputType(InputType.TYPE_CLASS_PHONE);
        return e;
    }

    private boolean validIp(String ip) {
        String[] parts = ip.split("\\.", -1);
        if (parts.length != 4) return false;
        for (String part : parts) {
            if (part.length() == 0 || part.length() > 3 || !part.matches("[0-9]+")) return false;
            int n = Integer.parseInt(part);
            if (n > 255) return false;
        }
        return true;
    }

    private Button utility(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(ColorStateList.valueOf(Color.rgb(35, 51, 68)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(53));
        lp.bottomMargin = dp(9);
        b.setLayoutParams(lp);
        return b;
    }

    private TextView label(String text, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        return drawable;
    }

    private int dp(int x) { return (int) (x * getResources().getDisplayMetrics().density + 0.5f); }
    private void toast(String text) { Toast.makeText(this, text, Toast.LENGTH_LONG).show(); }
}
