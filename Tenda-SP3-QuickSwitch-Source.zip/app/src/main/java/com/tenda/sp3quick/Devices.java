package com.tenda.sp3quick;

import android.content.Context;
import android.content.SharedPreferences;

final class Devices {
    static final String LIGHT = "light";
    static final String FAN = "fan";
    static final int UNKNOWN = -1;
    static final int PENDING = -2;

    static String name(String device) { return LIGHT.equals(device) ? "电灯" : "电风扇"; }
    static String icon(String device) { return LIGHT.equals(device) ? "💡" : "🌀"; }
    static String defaultIp(String device) { return LIGHT.equals(device) ? "192.168.0.30" : "192.168.0.31"; }
    static String mac(String device) { return LIGHT.equals(device) ? "D8:32:14:65:62:B8" : "D8:32:14:65:63:6C"; }

    private static SharedPreferences pref(Context ctx) {
        return ctx.getApplicationContext().getSharedPreferences("plugs", Context.MODE_PRIVATE);
    }
    static String ip(Context ctx, String device) { return pref(ctx).getString(device + "_ip", defaultIp(device)); }
    static void setIp(Context ctx, String device, String ip) { pref(ctx).edit().putString(device + "_ip", ip).apply(); }
    static int status(Context ctx, String device) { return pref(ctx).getInt(device + "_status", UNKNOWN); }
    static void setStatus(Context ctx, String device, int state) {
        pref(ctx).edit().putInt(device + "_status", state).apply();
        WidgetHelper.updateAll(ctx);
    }
    static String error(Context ctx, String device) { return pref(ctx).getString(device + "_error", ""); }
    static void setError(Context ctx, String device, String value) { pref(ctx).edit().putString(device + "_error", value).apply(); }
    static boolean verifyMac(Context ctx) { return pref(ctx).getBoolean("verify_mac", true); }
    static void setVerifyMac(Context ctx, boolean enabled) { pref(ctx).edit().putBoolean("verify_mac", enabled).apply(); }
}
